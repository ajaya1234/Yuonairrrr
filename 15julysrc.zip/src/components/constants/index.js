export const rtc = {

    client: null,

    localAudioTrack: null,
    localVideoTrack: null,
  };
  
  export const options = {

    appId: "537ee9fcc8f24c33b4b823896c9db588",

    token: "006537ee9fcc8f24c33b4b823896c9db588IAAzRQNcaZOCcHrvcWMeaD0fHyJZDo3PcQwpd7O1seSGI5YALE4AAAAAIgB6ijibRraaZAQAAQDWcplkAgDWcplkAwDWcplkBADWcplk",
  };